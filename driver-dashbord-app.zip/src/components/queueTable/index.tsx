import { motion} from "framer-motion";
import {CheckCircle2,  Clock, RefreshCw, XCircle} from "lucide-react";
import {ChangeEvent, Dispatch, ReactNode, SetStateAction,  useState} from "react";

import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TablePagination from '@mui/material/TablePagination';
import TableRow from '@mui/material/TableRow';
import FolderIcon from '@mui/icons-material/Folder';
import {Button} from "@mui/material";
import api from "../../api/api.ts";
import RejectModal from "../RejectModal";
import {toast} from "react-toastify";
import FileUploadModal from "../fileUploadModal";
import EmailIcon from '@mui/icons-material/Email';
import {useNavigate} from "react-router-dom";
import {AxiosError} from "axios";



interface Driver {
    id: number;
    is_verified: string;
    in_egs: number;
    phone_number: string;
    telegram_chat_id: string;
    fio: string;
    number: string;
    source_db: string;
    is_existing_driver: boolean;
    additional_info: string;
    last_login_at: string;
    created_at: string;
    updated_at: string;
    deleted_at: string | null;
    is_online: number;
    fcm_token: string;
}

export interface BorderQueue {
    id: number;
    driver_id: number;
    border_name: string;
    date: string;
    time_from: string;
    time_to: string;
    has_cmr: number;
    price: number;
    status: Status;
    created_at: string;
    updated_at: string;
    driver: Driver;
    files:File[]
}


interface File {
    id: number;
    queue_id: number;
    path: string;
    type: string;
    status: "approved" | "pending" | "rejected" | string;
    created_at: string; // yoki Date
    updated_at: string; // yoki Date
}


// API dan qaytadigan pagination meta
interface PaginationMeta {
    current_page: number;
    last_page: number;
    per_page: number;
    total: number;
    from: number;
    to: number;
}


interface Column {
    id: 'name' | 'code' | 'population' | 'size' | 'density' | 'time' | 'cmr'  | 'action';
    label: string;
    minWidth?: number;
    align?: 'left';
    format?: (value: number) => string;
}


const columns: readonly Column[] = [
    {id: 'name', label: 'ID', minWidth: 170},
    {id: 'code', label: 'DRIVER INFORMATION', minWidth: 100},
    {
        id: 'population',
        label: 'Hujjatlar',
        minWidth: 170,
        align: 'left',
        format: (value: number) => value.toLocaleString('en-US')
    },
    {
        id: 'size',
        label: 'To‘lov',
        minWidth: 170,
        align: 'left',
        format: (value: number) => value.toLocaleString('en-US')
    },
    {
        id: 'density',
        label: "Navbat ma'lumotlari",
        minWidth: 170,
        align: 'left',
        format: (value: number) => value.toFixed(2)
    },
    {id: 'cmr', label: "Cmr", minWidth: 170, align: 'left', format: (value: number) => value.toFixed(2)},
    {id: 'time', label: "Vaqt", minWidth: 170, align: 'left', format: (value: number) => value.toFixed(2)},
    {id: 'action', label: "Amallar", minWidth: 170, align: 'left', format: (value: number) => value.toFixed(2)},
];






const statusConfig: Record<Status, { label: string; classes: string; icon: ReactNode }> = {
    pending: {
        label: "Pending",
        classes: "bg-yellow-50 text-yellow-800 ring-1 ring-yellow-200",
        icon: <Clock size={11} className="text-yellow-500" />,
    },
    pending_review: {
        label: "In Review",
        classes: "bg-blue-50 text-blue-800 ring-1 ring-blue-200",
        icon: <RefreshCw size={11} className="text-blue-500" />,
    },
    payment_uploaded: {
        label: "Payment Uploaded",
        classes: "bg-amber-50 text-amber-800 ring-1 ring-amber-200",
        icon: <CheckCircle2 size={11} className="text-amber-600" />,
    },
    payment_approved: {
        label: "Payment Approved",
        classes: "bg-teal-50 text-teal-800 ring-1 ring-teal-200",
        icon: <CheckCircle2 size={11} className="text-teal-600" />,
    },
    waiting_payment: {
        label: "Waiting Payment",
        classes: "bg-fuchsia-50 text-fuchsia-800 ring-1 ring-fuchsia-200",
        icon: <XCircle size={11} className="text-fuchsia-600" />,
    },
    approved: {
        label: "Approved",
        classes: "bg-emerald-50 text-emerald-800 ring-1 ring-emerald-200",
        icon: <CheckCircle2 size={11} className="text-emerald-500" />,
    },
    rejected: {
        label: "Rejected",
        classes: "bg-red-50 text-red-800 ring-1 ring-red-200",
        icon: <XCircle size={11} className="text-red-500" />,
    },
    cancelled: {
        label: "Cancelled",
        classes: "bg-gray-50 text-gray-700 ring-1 ring-gray-200",
        icon: <XCircle size={11} className="text-gray-500" />,
    },
};

type Status =
    | 'pending'
    | 'pending_review'
    | 'waiting_payment'
    | 'payment_uploaded'
    | 'payment_approved'
    | 'approved'
    | 'rejected'
    | 'cancelled'; // <-- qo‘shildi




interface QueueTableProps {
    loading: boolean;
    data: BorderQueue[];
    meta: PaginationMeta;
    setCurrentPage: Dispatch<SetStateAction<number>>;
    currentPage: number;
    handleOpenDocs:(item:BorderQueue) => void;
    refetch: () => void; // ← QO'SHILDI
    type:string;
}




function QueueTable({ type='queue' ,  data , handleOpenDocs , refetch , setCurrentPage , currentPage}: QueueTableProps) {





    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const [rejectModal, setRejectModal] = useState<{
        open: boolean;
        type: "queue" | "payment" | null;
    }>({ open: false, type: null });
    const [isOpen , setIsOpen] = useState<boolean>(false);
    const [selectedId, setSelectedId] = useState<number | null>(null);
    const [comment, setComment] = useState<string>("");
    const navigate = useNavigate();





    const handleConfirmReject = async (comment: string , id:number) => {
        const endpoint =
            rejectModal.type === "payment"
                ? `/admin/${type}/${id}/reject-payment`
                : `/admin/${type}/${id}/reject`;
        try {
            await api.post(endpoint, { comment });
            toast.success("Navbat bekor qilindi");
            refetch()

        } catch (error:any) {
            console.log(error);
            toast.error(error.response.data.message || "Ma'lumotlarni olishda xatolik");
        }
    };


    const handleChangePage =  (event:unknown, newPage: number) => {
        setPage(newPage);
        setCurrentPage(newPage+1);
        console.log(newPage+1);
    };

    const handleChangeRowsPerPage = (event: ChangeEvent<HTMLInputElement>) => {
        setRowsPerPage(+event.target.value);
        setPage(0);
    };





    const handleConfirmPolis = async (id:number) => {
        try {
            const res = await api.post(`/admin/${type}/${id}/waiting-payment`)
            console.log(res)
            toast.success("Polis tasdiqlandi");
            refetch()

        }catch (e:AxiosError) {
            console.error(e);
            toast.error(e.response.data.message || "Ma'lumotlarni olishda xatolik");

        }
    }
    const handleRejectedPolis = async (id:number) => {
        try {
            const res = await api.post(`/admin/${type}/${id}/cancelled`)
            console.log(res)
            toast.success("Polis tasdiqlanmadi");
            refetch()

        }catch (e) {
            console.error(e);
            toast.error(e.response.data.message || "Ma'lumotlarni olishda xatolik");

        }
    }

    const handleConfirmPayment = async (id:number) => {
        try {
            const res = await api.post(`/admin/${type}/${id}/approve-payment`)
            console.log(res)
            toast.success("Check tasdiqlandi");
            refetch()

        }catch (e) {
            console.error(e);
            toast.error(e.response.data.message || "Ma'lumotlarni olishda xatolik");

        }
    }
    const handleRejectedPayment = async (id:number) => {
        try {
            const res = await api.post(`/admin/${type}/${id}/reject-payment`)
            console.log(res)
            toast.success("Check tasdiqlanmadi");
            refetch()

        }catch (e) {
            console.error(e);
            toast.error(e.response.data.message || "Ma'lumotlarni olishda xatolik");

        }
    }




    return (
        <motion.div
            initial={{opacity: 0, y: 16}}
            animate={{opacity: 1, y: 0}}
            transition={{delay: 0.28, duration: 0.4}}
            className="bg-white rounded-2xl shadow-sm overflow-hidden"
        >


            <Paper sx={{width: '100%', overflow: 'hidden'}}>
                <TableContainer>
                    <Table stickyHeader aria-label="sticky table">
                        <TableHead>
                            <TableRow>
                                {columns.map((column) => (
                                    <TableCell
                                        key={column.id}
                                        align={column.align}
                                        // style={{minWidth: column.minWidth}}
                                    >
                                        {column.label}
                                    </TableCell>
                                ))}
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {data && data.map((item) => {


                                const cfg = statusConfig[item.status];

                                return (
                                    <TableRow hover role="checkbox" tabIndex={-1} key={item.id}>
                                        <TableCell>
                                            {item?.id}
                                        </TableCell>
                                        <TableCell>
                                            <div className={''}>
                                                <p className="text-[13.5px] font-semibold text-gray-900">
                                                    {item?.driver?.fio}
                                                </p>
                                                <p className="text-[11.5px] text-gray-400 mt-0.5">
                                                    {/*ID: {item?.driver?.id}*/}
                                                    {item?.driver?.phone_number}
                                                </p>
                                            </div>
                                        </TableCell>
                                        <TableCell>
                                            <div className={'flex items-center gap-x-2'}>
                                                <Button onClick={()=>handleOpenDocs(item)} variant={'outlined'} color={'info'} sx={{borderRadius: 8}}
                                                        className={'py-1 px-2 border w-max rounded-[20px] cursor-pointer'}>
                                                    <FolderIcon color={'info'}/>
                                                    <p className={'ml-2'}>{item?.files.filter((obj)=> obj.type !== 'payment_check').length}</p>
                                                </Button>

                                                {
                                                    item.status === 'pending_review' ?
                                                        (
                                                            <div className={'flex flex-col gap-y-2'}>
                                                                <Button
                                                                    variant={'contained'}
                                                                    color={'success'}
                                                                    size={'small'}
                                                                    onClick={()=> handleConfirmPolis(item.id)}
                                                                >
                                                                    Confirm
                                                                </Button>
                                                                <Button
                                                                    variant={'contained'}
                                                                    color={'error'}
                                                                    size={'small'}
                                                                    onClick={()=> handleRejectedPolis(item.id)}

                                                                >
                                                                    Cancel
                                                                </Button>
                                                            </div>
                                                        )
                                                        :
                                                        null
                                                }
                                            </div>
                                        </TableCell>
                                        <TableCell>
                                             <span
                                                 className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11.5px] font-semibold ${cfg?.classes}`}>
                                                    {cfg?.icon}
                                                 {cfg?.label}
                                                </span>
                                        </TableCell>
                                        <TableCell>
                                            <p className="text-[13.5px] font-medium text-gray-800">
                                                {item.border_name}
                                            </p>
                                        </TableCell>
                                        <TableCell>

                                            <div className={'flex items-center gap-x-2'}>
                                                <Button onClick={()=>handleOpenDocs(item)} variant={'outlined'} color={'info'} sx={{borderRadius: 8}}
                                                        className={'py-1 px-2 border w-max rounded-[20px] cursor-pointer'}>
                                                    <FolderIcon color={'info'}/>
                                                    <p className={'ml-2'}>{item?.files.filter((obj)=> obj.type === 'payment_check').length}</p>
                                                </Button>

                                                {
                                                    item.status === 'payment_uploaded' ?
                                                        (
                                                            <div className={'flex flex-col gap-y-2'}>
                                                                <Button
                                                                    variant={'contained'}
                                                                    color={'success'}
                                                                    size={'small'}
                                                                    onClick={()=> handleConfirmPayment(item.id)}
                                                                >
                                                                    Confirm
                                                                </Button>
                                                                <Button
                                                                    variant={'contained'}
                                                                    color={'error'}
                                                                    size={'small'}
                                                                    onClick={()=> handleRejectedPayment(item.id)}
                                                                >
                                                                    Cancel
                                                                </Button>
                                                            </div>
                                                        )
                                                        :
                                                        null
                                                }
                                            </div>



                                        </TableCell>
                                        <TableCell>
                                            {item.date}
                                        </TableCell>
                                        <TableCell>


                                            <div className={'flex gap-x-2 items-center'}>

                                                        <Button
                                                            onClick={()=> {
                                                                setSelectedId(item?.id)
                                                                setIsOpen(true)
                                                            }}
                                                            // fullWidth={true}

                                                            variant={'contained'}
                                                            color={'success'}
                                                            size={'small'}
                                                        >
                                                            Confirm
                                                        </Button>

                                                        <Button
                                                            onClick={()=> {
                                                                setSelectedId(item?.id)
                                                                setRejectModal({open: true, type: "queue"})
                                                            }}
                                                            // fullWidth={true}
                                                            variant={'contained'}
                                                            color={'error'}
                                                            size={'small'}
                                                        >
                                                            Cancel
                                                        </Button>


                                                <Button onClick={()=>navigate(`/chats/${item?.driver?.id}`)} variant={'outlined'} color={'info'} sx={{borderRadius: 8}}
                                                        className={'py-1 px-2 border w-max rounded-[20px] cursor-pointer'}>
                                                    <EmailIcon color={'info'}/>
                                                </Button>

                                            </div>
                                        </TableCell>
                                    </TableRow>
                                );
                            })}
                        </TableBody>
                    </Table>
                </TableContainer>
                <TablePagination
                    rowsPerPageOptions={[10, 25, 100]}
                    component="div"
                    count={data?.length}
                    rowsPerPage={rowsPerPage}
                    page={page}
                    onPageChange={handleChangePage}
                    onRowsPerPageChange={handleChangeRowsPerPage}
                />
            </Paper>




            <RejectModal
                comment={comment}
                setComment={setComment}
                isOpen={rejectModal.open}
                onClose={() => setRejectModal({ open: false, type: null })}
                onConfirm={()=>handleConfirmReject(comment , selectedId as number)}
                title={rejectModal.type === "payment" ? "To'lovni rad etish" : "Navbatni bekor qilish"}
                subtitle={
                    rejectModal.type === "payment"
                        ? "To'lov tasdiqlanmaydi"
                        : "Ushbu navbat bekor qilinadi"
                }
            />


            <FileUploadModal  refetch={refetch}  setSelectedId={setSelectedId} selectedId={selectedId} isOpen={isOpen} setIsOpen={setIsOpen}/>


        </motion.div>
    );
}

export default QueueTable;