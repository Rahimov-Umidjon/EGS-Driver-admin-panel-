import {useState, useCallback, useEffect} from "react";
import {motion, AnimatePresence} from "framer-motion";
import {
    X,
    ZoomIn,
    ZoomOut,
    Download,
    ChevronLeft,
    ChevronRight,
    Maximize2,
    FileText,
    Shield,
    Receipt,
} from "lucide-react";

// ─── TYPES ───────────────────────────────────────────────────────────────────

type CategoryKey =
    "polis"
    | "cmr"
    | "chek"
    | 'invoice'
    | 'packing_list'
    | 'export_declaration'
    | 'tir'
    | 'ct1'
    | 'fito'
    | 'obshiy_forma'
    | 'forma_a';


interface ImageItem {
    id: number;
    queue_id: number;
    path: string;
    type: string;
    status: "approved" | "pending" | "rejected" | string;
    created_at: string; // yoki Date
    updated_at: string; // yoki Date
}

interface CategoryData {
    key: CategoryKey;
    label: string;
    icon: React.ReactNode;
    color: string;
    accent: string;
    images: ImageItem[];
}

interface ImageViewerModalProps {
    open: boolean;
    onClose: () => void;
    /** Pass real image URLs from your API here */
    images?: {
        polis?: ImageItem[];
        cmr?: ImageItem[];
        chek?: ImageItem[];
        invoice?: ImageItem[];
        packing_list?: ImageItem[];
        export_declaration?: ImageItem[];
        tir?: ImageItem[];
        ct1?: ImageItem[];
        fito?: ImageItem[];
        obshiy_forma?: ImageItem[];
        forma_a?: ImageItem[];

    };
    imgType?: string[];
}

// ─── MOCK DATA (replace with real API data) ───────────────────────────────────


const BASE_URL = "https://mobile-test.izisol.uz/storage/";


// ─── CATEGORY CONFIG ──────────────────────────────────────────────────────────

const getCategoryConfig = (images: ImageViewerModalProps["images"]): CategoryData[] => [
    {
        key: "polis",
        label: "Polis",
        icon: <Shield size={14}/>,
        color: "from-blue-600 to-blue-800",
        accent: "#3b82f6",
        images: images?.polis ?? [],
    },
    {
        key: "cmr",
        label: "CMR",
        icon: <FileText size={14}/>,
        color: "from-emerald-600 to-emerald-800",
        accent: "#10b981",
        images: images?.cmr ?? [],
    },
    {
        key: "chek",
        label: "Chek",
        icon: <Receipt size={14}/>,
        color: "from-violet-600 to-violet-800",
        accent: "#8b5cf6",
        images: images?.chek ?? [],
    },
    {
        key: "invoice",
        label: "Invoice",
        icon: <FileText size={14}/>,
        color: "from-orange-600 to-orange-800",
        accent: "#f97316",
        images: images?.invoice ?? [],
    },
    {
        key: "packing_list",
        label: "Packing List",
        icon: <FileText size={14}/>,
        color: "from-yellow-600 to-yellow-800",
        accent: "#eab308",
        images: images?.packing_list ?? [],
    },
    {
        key: "export_declaration",
        label: "Export Declaration",
        icon: <FileText size={14}/>,
        color: "from-red-600 to-red-800",
        accent: "#ef4444",
        images: images?.export_declaration ?? [],
    },
    {
        key: "tir",
        label: "TIR",
        icon: <FileText size={14}/>,
        color: "from-indigo-600 to-indigo-800",
        accent: "#6366f1",
        images: images?.tir ?? [],
    },
    {
        key: "ct1",
        label: "CT-1",
        icon: <FileText size={14}/>,
        color: "from-teal-600 to-teal-800",
        accent: "#14b8a6",
        images: images?.ct1 ?? [],
    },
    {
        key: "fito",
        label: "Fito",
        icon: <FileText size={14}/>,
        color: "from-green-600 to-green-800",
        accent: "#22c55e",
        images: images?.fito ?? [],
    },
    {
        key: "obshiy_forma",
        label: "Obshiy Forma",
        icon: <FileText size={14}/>,
        color: "from-gray-600 to-gray-800",
        accent: "#6b7280",
        images: images?.obshiy_forma ?? [],
    },
    {
        key: "forma_a",
        label: "Forma A",
        icon: <FileText size={14}/>,
        color: "from-pink-600 to-pink-800",
        accent: "#ec4899",
        images: images?.forma_a ?? [],
    },
];

// ─── LIGHTBOX ────────────────────────────────────────────────────────────────

interface LightboxProps {
    images: ImageItem[];
    startIndex: number;
    onClose: () => void;
    accentColor: string;
}

function Lightbox({images, startIndex, onClose, accentColor}: LightboxProps) {
    const [current, setCurrent] = useState(startIndex);
    const [zoom, setZoom] = useState(1);

    const prev = useCallback(() => {
        setCurrent((c) => (c - 1 + images.length) % images.length);
        setZoom(1);
    }, [images.length]);

    const next = useCallback(() => {
        setCurrent((c) => (c + 1) % images.length);
        setZoom(1);
    }, [images.length]);

    const handleDownload = () => {
        const link = document.createElement("a");
        link.href = images[current].path;
        link.download = images[current].type;
        link.click();
    };

    return (
        <motion.div
            initial={{opacity: 0}}
            animate={{opacity: 1}}
            exit={{opacity: 0}}
            className="fixed inset-0 z-[9999] flex flex-col"
            style={{background: "rgba(0,0,0,0.96)"}}
        >
            {/* Top bar */}
            <div className="flex items-center justify-between px-6 py-4 z-10">
                <div className="flex items-center gap-3">
          <span className="text-white/50 text-sm font-mono">
            {current + 1} / {images.length}
          </span>
                    <span className="text-white text-sm font-medium truncate max-w-[200px]">
            {images[current].type}
          </span>
                </div>

                <div className="flex items-center gap-2">
                    {/* Zoom out */}
                    <button
                        onClick={() => setZoom((z) => Math.max(0.5, z - 0.25))}
                        className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors"
                        title="Kichiklashtirish"
                    >
                        <ZoomOut size={18}/>
                    </button>

                    {/* Zoom level */}
                    <span className="text-white/60 text-xs w-10 text-center font-mono">
                        {Math.round(zoom * 100)}%
                      </span>

                    {/* Zoom in */}
                    <button
                        onClick={() => setZoom((z) => Math.min(4, z + 0.25))}
                        className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors"
                        title="Kattalashtirish"
                    >
                        <ZoomIn size={18}/>
                    </button>

                    {/* Reset zoom */}
                    <button
                        onClick={() => setZoom(1)}
                        className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors"
                        title="Asl o'lcham"
                    >
                        <Maximize2 size={18}/>
                    </button>

                    {/* Download */}
                    <button
                        onClick={handleDownload}
                        className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors"
                        title="Yuklab olish"
                    >
                        <Download size={18}/>
                    </button>

                    {/* Close */}
                    <button
                        onClick={onClose}
                        className="p-2 rounded-lg bg-white/10 hover:bg-red-500/80 text-white transition-colors ml-2"
                        title="Yopish"
                    >
                        <X size={18}/>
                    </button>
                </div>
            </div>

            {/* Image area */}
            <div className="flex-1 flex items-center justify-center overflow-hidden relative px-16">
                {/* Prev */}
                {images.length > 1 && (
                    <button
                        onClick={prev}
                        className="absolute left-4 p-3 rounded-full bg-white/10 hover:bg-white/25 text-white transition-all z-10"
                    >
                        <ChevronLeft size={24}/>
                    </button>
                )}

                <AnimatePresence mode="wait">
                    <motion.div
                        key={current}
                        initial={{opacity: 0, scale: 0.96}}
                        animate={{opacity: 1, scale: 1}}
                        exit={{opacity: 0, scale: 1.02}}
                        transition={{duration: 0.2}}
                        className="flex items-center justify-center w-full h-full"
                    >
                        <motion.img
                            src={BASE_URL + images[current].path}
                            alt={images[current].type}
                            style={{
                                transform: `scale(${zoom})`,
                                transformOrigin: "center center",
                                maxHeight: "calc(100vh - 160px)",
                                maxWidth: "100%",
                                objectFit: "contain",
                                transition: "transform 0.2s ease",
                                borderRadius: 8,
                                boxShadow: `0 0 60px ${accentColor}33`,
                            }}
                            draggable={false}
                        />
                    </motion.div>
                </AnimatePresence>

                {/* Next */}
                {images.length > 1 && (
                    <button
                        onClick={next}
                        className="absolute right-4 p-3 rounded-full bg-white/10 hover:bg-white/25 text-white transition-all z-10"
                    >
                        <ChevronRight size={24}/>
                    </button>
                )}
            </div>

            {/* Thumbnail strip */}
            {images.length > 1 && (
                <div className="flex items-center justify-center gap-2 py-4 px-6 overflow-x-auto">
                    {images.map((img, i) => (
                        <button
                            key={img.id}
                            onClick={() => {
                                setCurrent(i);
                                setZoom(1);
                            }}
                            className="flex-shrink-0 transition-all duration-200"
                            style={{
                                width: 56,
                                height: 42,
                                borderRadius: 6,
                                overflow: "hidden",
                                border: i === current ? `2px solid ${accentColor}` : "2px solid transparent",
                                opacity: i === current ? 1 : 0.45,
                            }}
                        >
                            <img src={BASE_URL + img.path} alt={img.type} className="w-full h-full object-cover"/>
                        </button>
                    ))}
                </div>
            )}
        </motion.div>
    );
}

// ─── MAIN MODAL ───────────────────────────────────────────────────────────────

export default function ImageViewerModal({open, onClose, images, imgType}: ImageViewerModalProps) {


    const [activeTab, setActiveTab] = useState<CategoryKey>("");
    const [lightbox, setLightbox] = useState<{ images: ImageItem[]; index: number; accent: string } | null>(null);

    const categories = getCategoryConfig(images).filter((obj) => imgType?.includes(obj.key));
    const activeCat = categories.find((c) => c.key === activeTab)!;

    const openLightbox = (imgs: ImageItem[], index: number, accent: string) => {
        setLightbox({images: imgs, index, accent});
    };

    useEffect(() => {
        if (imgType?.includes('polis')) {
            setActiveTab('polis')
        } else {
            setActiveTab('cmr')
        }
    }, [imgType]);

    return (
        <>
            <AnimatePresence>
                {open && (
                    <>
                        {/* Backdrop */}
                        <motion.div
                            key="backdrop"
                            initial={{opacity: 0}}
                            animate={{opacity: 1}}
                            exit={{opacity: 0}}
                            onClick={onClose}
                            className="fixed inset-0 z-[1200]"
                            style={{background: "rgba(15,23,42,0.75)", backdropFilter: "blur(2px)"}}
                        />

                        {/* Modal */}
                        <motion.div
                            key="modal"
                            initial={{opacity: 0, y: 32, scale: 0.97}}
                            animate={{opacity: 1, y: 0, scale: 1}}
                            exit={{opacity: 0, y: 24, scale: 0.97}}
                            transition={{type: "spring", damping: 28, stiffness: 320}}
                            className="fixed inset-0 z-[1300] flex items-center justify-center p-4 pointer-events-none"
                        >
                            <div
                                className="pointer-events-auto w-full max-w-[1500px] rounded-2xl overflow-hidden shadow-2xl"
                                style={{
                                    background: "#0f172a",
                                    border: "1px solid rgba(255,255,255,0.08)",
                                    maxHeight: "90vh",
                                    display: "flex",
                                    flexDirection: "column",
                                }}
                            >
                                {/* Header */}
                                <div className="flex items-center justify-between px-6 py-4 border-b border-white/8">
                                    <div>
                                        <h2 className="text-white font-semibold text-base tracking-tight">
                                            Hujjatlar
                                        </h2>
                                        <p className="text-white/40 text-xs mt-0.5">
                                            Rasmlarni ko'rish va yuklab olish
                                        </p>
                                    </div>
                                    <button
                                        onClick={onClose}
                                        className="p-2 rounded-lg hover:bg-white/10 text-white/60 hover:text-white transition-colors"
                                    >
                                        <X size={18}/>
                                    </button>
                                </div>

                                {/* Tabs */}
                                <div className="flex gap-1 px-6 pt-4">
                                    {categories.map((cat) => (
                                        <button
                                            key={cat.key}
                                            onClick={() => setActiveTab(cat.key)}
                                            className="relative flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all duration-200"
                                            style={{
                                                color: activeTab === cat.key ? "#fff" : "rgba(255,255,255,0.4)",
                                                background: activeTab === cat.key ? cat.accent + "22" : "transparent",
                                            }}
                                        >
                                            {activeTab === cat.key && (
                                                <motion.div
                                                    layoutId="tab-pill"
                                                    className="absolute inset-0 rounded-xl"
                                                    style={{
                                                        background: cat.accent + "18",
                                                        border: `1px solid ${cat.accent}44`
                                                    }}
                                                    transition={{type: "spring", damping: 24, stiffness: 300}}
                                                />
                                            )}
                                            <span style={{
                                                color: activeTab === cat.key ? cat.accent : undefined,
                                                position: "relative"
                                            }}>
                                                {cat.icon}
                                            </span>
                                            <span className="relative">{cat.label}</span>
                                            <span
                                                className="relative text-[11px] rounded-full px-1.5 py-0.5 font-mono"
                                                style={{
                                                    background: activeTab === cat.key ? cat.accent + "33" : "rgba(255,255,255,0.08)",
                                                    color: activeTab === cat.key ? cat.accent : "rgba(255,255,255,0.4)",
                                                }}
                                            >
                                                {cat.images.length}
                                            </span>
                                        </button>
                                    ))}
                                </div>

                                {/* Image Grid */}
                                <div className="flex-1 overflow-y-auto p-6 pt-4">
                                    <AnimatePresence mode="wait">
                                        <motion.div
                                            key={activeTab}
                                            initial={{opacity: 0, y: 8}}
                                            animate={{opacity: 1, y: 0}}
                                            exit={{opacity: 0}}
                                            transition={{duration: 0.18}}
                                            className="grid grid-cols-2 sm:grid-cols-3 gap-3"
                                        >
                                            {activeCat?.images.length === 0 ? (
                                                <div
                                                    className="col-span-3 flex flex-col items-center justify-center py-16 text-white/30">
                                                    <FileText size={40} className="mb-3 opacity-40"/>
                                                    <p className="text-sm">Hujjat topilmadi</p>
                                                </div>
                                            ) : (
                                                activeCat?.images.map((img, i) => (
                                                    <motion.div
                                                        key={img.id}
                                                        initial={{opacity: 0, scale: 0.94}}
                                                        animate={{opacity: 1, scale: 1}}
                                                        transition={{delay: i * 0.05}}
                                                        className="group relative rounded-xl overflow-hidden cursor-pointer"
                                                        style={{
                                                            aspectRatio: "4/3",
                                                            background: "rgba(255,255,255,0.04)",
                                                            border: "1px solid rgba(255,255,255,0.08)",
                                                        }}
                                                        onClick={() => openLightbox(activeCat?.images, i, activeCat?.accent)}
                                                    >
                                                        <img
                                                            src={BASE_URL + img.path} alt={img.type}
                                                            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                                                        />

                                                        {/* Hover overlay */}
                                                        <div
                                                            className="absolute inset-0 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200"
                                                            style={{background: "rgba(0,0,0,0.6)"}}
                                                        >
                                                            <Maximize2 size={22} className="text-white mb-2"/>
                                                            <span
                                                                className="text-white text-xs font-medium">Ko'rish</span>
                                                        </div>

                                                        {/* Label */}
                                                        <div
                                                            className="absolute bottom-0 left-0 right-0 px-3 py-2"
                                                            style={{
                                                                background: "linear-gradient(to top, rgba(0,0,0,0.8), transparent)",
                                                            }}
                                                        >
                                                            <p className="text-white text-[11px] font-medium truncate">{img.type}</p>
                                                        </div>

                                                        {/* Download btn on hover */}
                                                        <button
                                                            onClick={(e) => {
                                                                e.stopPropagation();
                                                                const link = document.createElement("a");
                                                                link.href = img.path;
                                                                link.download = img.type;
                                                                link.click();
                                                            }}
                                                            className="absolute top-2 right-2 p-1.5 rounded-lg opacity-0 group-hover:opacity-100 transition-all"
                                                            style={{background: "rgba(0,0,0,0.6)"}}
                                                            title="Yuklab olish"
                                                        >
                                                            <Download size={13} className="text-white"/>
                                                        </button>
                                                    </motion.div>
                                                ))
                                            )}
                                        </motion.div>
                                    </AnimatePresence>
                                </div>
                            </div>
                        </motion.div>
                    </>
                )}
            </AnimatePresence>

            {/* Lightbox */}
            <AnimatePresence>
                {lightbox && (
                    <Lightbox
                        images={lightbox.images}
                        startIndex={lightbox.index}
                        accentColor={lightbox.accent}
                        onClose={() => setLightbox(null)}
                    />
                )}
            </AnimatePresence>
        </>
    );
}


// ─── HOW TO USE IN QueueTable ─────────────────────────────────────────────────
/*
import { useState } from "react";
import ImageViewerModal from "./ImageViewerModal";

// Inside QueueTable component:
const [modalOpen, setModalOpen] = useState(false);
const [selectedImages, setSelectedImages] = useState(null);

const handleOpenDocs = (item: BorderQueue) => {
  setSelectedImages({
    polis: item.polis_images,   // your API field
    cmr:   item.cmr_images,     // your API field
    chek:  item.chek_images,    // your API field
  });
  setModalOpen(true);
};

// In JSX replace the Button:
<Button
  variant="outlined"
  color="info"
  sx={{ borderRadius: 8 }}
  onClick={() => handleOpenDocs(item)}
>
  <FolderIcon color="info" />
</Button>

<ImageViewerModal
  open={modalOpen}
  onClose={() => setModalOpen(false)}
  images={selectedImages}
/>
*/