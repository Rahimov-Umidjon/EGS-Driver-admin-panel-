'use client';

import type React from "react";
import { useState, useEffect, useRef } from "react";
import { X, User, Calendar, FileText, Image, Loader2, AlertCircle, Reply, Send, Paperclip } from "lucide-react";
import { useAuth } from "../../context/AuthContext";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

interface Driver {
    fio: string;
    number: string;
}

interface Reply {
    id: number;
    comment: string;
    files: string[];
    admin_name: string;
    created_at: string;
}

interface Comment {
    id: number;
    driver_id: number;
    order_id: number;
    source: string;
    comment: string | null;
    files: string[];
    files_count: number;
    created_at: string;
    driver: Driver;
    replies_count: number;
    replies: Reply[];
    file_path: string;
}

interface CommentsResponse {
    status: boolean;
    current_page: number;
    last_page: number;
    per_page: number;
    total: number;
    data: Comment[];
}

interface ReplyResponse {
    status: boolean;
    message: string;
    reply: {
        id: number;
        parent_id: number;
        comment: string;
        files: string[];
        files_count: number;
        admin_name: string;
        created_at: string;
    };
}

const Comments: React.FC = () => {
    const [selectedImage, setSelectedImage] = useState<string | null>(null);
    const [commentsData, setCommentsData] = useState<CommentsResponse | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [replyingTo, setReplyingTo] = useState<number | null>(null);
    const [replyText, setReplyText] = useState("");
    const [replyFiles, setReplyFiles] = useState<FileList | null>(null);
    const [sendingReply, setSendingReply] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const [currentPage, setCurrentPage] = useState(1);
    const [expandedReplies, setExpandedReplies] = useState<Set<number>>(new Set());
    const { token } = useAuth();

    useEffect(() => {
        const fetchComments = async () => {
            try {
                setLoading(true);
                setError(null);

                const response = await fetch(`https://mobile-test.izisol.uz/api/admin/all-comments?page=${currentPage}`, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                        Accept: "application/json",
                    },
                });

                if (!response.ok) {
                    throw new Error(`HTTP xatosi! Status: ${response.status}`);
                }

                const data: CommentsResponse = await response.json();
                setCommentsData(data);
            } catch (err) {
                setError(err instanceof Error ? err.message : "Izohlar yuklanmadi");
                console.error("Izohlar yuklashda xato:", err);
            } finally {
                setLoading(false);
            }
        };

        if (token) {
            fetchComments();
        }
    }, [token, currentPage]);

    const openImageModal = (imagePath: string) => {
        setSelectedImage(imagePath);
        document.body.style.overflow = 'hidden';
    };

    const closeImageModal = () => {
        setSelectedImage(null);
        document.body.style.overflow = 'unset';
    };

    const startReply = (commentId: number) => {
        setReplyingTo(commentId);
        setReplyText("");
        setReplyFiles(null);
        if (fileInputRef.current) {
            fileInputRef.current.value = "";
        }
    };

    const cancelReply = () => {
        setReplyingTo(null);
        setReplyText("");
        setReplyFiles(null);
        if (fileInputRef.current) {
            fileInputRef.current.value = "";
        }
    };

    const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
        const files = e.target.files;
        setReplyFiles(files);
    };

    const toggleReplies = (commentId: number) => {
        const newExpanded = new Set(expandedReplies);
        if (newExpanded.has(commentId)) {
            newExpanded.delete(commentId);
        } else {
            newExpanded.add(commentId);
        }
        setExpandedReplies(newExpanded);
    };

    const changePage = (page: number) => {
        if (page >= 1 && page <= (commentsData?.last_page || 1)) {
            setCurrentPage(page);
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    };

    const sendReply = async (commentId: number) => {
        if (!replyText.trim() && (!replyFiles || replyFiles.length === 0)) {
            toast.error("Iltimos, izoh yozing yoki fayl biriktiring", {
                position: "top-right",
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                theme: "colored",
            });
            return;
        }

        try {
            setSendingReply(true);

            const formData = new FormData();
            formData.append('comment', replyText.trim());

            if (replyFiles) {
                Array.from(replyFiles).forEach((file) => {
                    formData.append('files[]', file);
                });
            }

            const response = await fetch(`https://mobile-test.izisol.uz/api/admin/comments/${commentId}/reply`, {
                method: 'POST',
                headers: {
                    Authorization: `Bearer ${token}`,
                    Accept: "application/json",
                },
                body: formData,
            });

            if (!response.ok) {
                throw new Error(`HTTP xatosi! Status: ${response.status}`);
            }

            const data: ReplyResponse = await response.json();

            if (data.status) {
                toast.success("Javob muvaffaqiyatli yuborildi!", {
                    position: "top-right",
                    autoClose: 3000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    theme: "colored",
                });

                cancelReply();

                // Refresh comments
                const refreshResponse = await fetch(`https://mobile-test.izisol.uz/api/admin/all-comments?page=${currentPage}`, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                        Accept: "application/json",
                    },
                });
                if (refreshResponse.ok) {
                    const refreshData: CommentsResponse = await refreshResponse.json();
                    setCommentsData(refreshData);
                    setExpandedReplies(prev => new Set([...prev, commentId]));
                }
            } else {
                throw new Error("Javob yuborishda xatolik");
            }
        } catch (err) {
            console.error("Javob yuborishda xato:", err);
            toast.error(err instanceof Error ? err.message : "Javob yuborishda xatolik", {
                position: "top-right",
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                theme: "colored",
            });
        } finally {
            setSendingReply(false);
        }
    };

    const renderPaginationButtons = () => {
        if (!commentsData || commentsData.last_page <= 1) return null;

        const buttons = [];
        const currentPageNum = commentsData.current_page;
        const lastPage = commentsData.last_page;

        buttons.push(
            <button
                key="prev"
                onClick={() => changePage(currentPageNum - 1)}
                disabled={currentPageNum === 1}
                className="px-3 py-2 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
                Oldingi
            </button>
        );

        const startPage = Math.max(1, currentPageNum - 2);
        const endPage = Math.min(lastPage, currentPageNum + 2);

        if (startPage > 1) {
            buttons.push(
                <button
                    key={1}
                    onClick={() => changePage(1)}
                    className="px-3 py-2 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 transition-colors"
                >
                    1
                </button>
            );
            if (startPage > 2) {
                buttons.push(<span key="dots1" className="px-2 text-slate-500">...</span>);
            }
        }

        for (let i = startPage; i <= endPage; i++) {
            buttons.push(
                <button
                    key={i}
                    onClick={() => changePage(i)}
                    className={`px-3 py-2 rounded-lg border transition-colors ${
                        i === currentPageNum
                            ? 'bg-blue-600 text-white border-blue-600'
                            : 'border-slate-300 text-slate-700 hover:bg-slate-50'
                    }`}
                >
                    {i}
                </button>
            );
        }

        if (endPage < lastPage) {
            if (endPage < lastPage - 1) {
                buttons.push(<span key="dots2" className="px-2 text-slate-500">...</span>);
            }
            buttons.push(
                <button
                    key={lastPage}
                    onClick={() => changePage(lastPage)}
                    className="px-3 py-2 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 transition-colors"
                >
                    {lastPage}
                </button>
            );
        }

        buttons.push(
            <button
                key="next"
                onClick={() => changePage(currentPageNum + 1)}
                disabled={currentPageNum === lastPage}
                className="px-3 py-2 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
                Keyingi
            </button>
        );

        return (
            <div className="flex justify-center gap-2 mt-8">
                {buttons}
            </div>
        );
    };

    if (loading) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
                <div className="text-center">
                    <Loader2 className="w-12 h-12 animate-spin text-blue-600 mx-auto mb-4" />
                    <h2 className="text-xl font-semibold text-slate-700 mb-2">Izohlar yuklanmoqda</h2>
                    <p className="text-slate-500">Haydovchi izohlari yuklanmoqda...</p>
                </div>
            </div>
        );
    }

    if (error) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
                <div className="text-center max-w-md mx-auto p-6">
                    <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
                    <h2 className="text-xl font-semibold text-slate-700 mb-2">Izohlar yuklanmadi</h2>
                    <p className="text-slate-500 mb-4">{error}</p>
                    <button
                        onClick={() => window.location.reload()}
                        className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                    >
                        Qayta urinish
                    </button>
                </div>
            </div>
        );
    }

    if (!commentsData) {
        return null;
    }

    return (
        <div className="min-h-screen bg-white p-4 md:p-6">
            <div className="max-w-6xl mx-auto">
                <div className="text-center mb-8">
                    <h1 className="text-4xl font-bold text-slate-800 mb-2">Haydovchi izohlari</h1>
                    <p className="text-slate-600">Jonli muloqot tarixi</p>
                    <div className="flex justify-center gap-4 mt-4 text-sm text-slate-500">
                        <span>
                            Sahifa {commentsData.current_page} / {commentsData.last_page}
                        </span>
                        <span>•</span>
                        <span>Jami izohlar: {commentsData.total}</span>
                        <span>•</span>
                        <span>Bu sahifada: {commentsData.data.length}</span>
                    </div>
                </div>

                <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
                    {commentsData.data.map((comment) => (
                        <div
                            key={comment.id}
                            className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 hover:shadow-md hover:border-slate-300 transition-all duration-300 transform hover:-translate-y-1"
                        >
                            <div className="flex justify-between items-start mb-4">
                                <div className="flex items-center gap-2">
                                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                                        <span className="text-blue-600 font-semibold text-sm">#{comment.id}</span>
                                    </div>
                                    <div>
                                        <h2 className="text-lg font-semibold text-slate-800">Izoh #{comment.id}</h2>
                                    </div>
                                </div>
                                <div className="flex items-center gap-1 text-slate-500">
                                    <Calendar className="w-4 h-4" />
                                    <span className="text-xs">{new Date(comment.created_at).toLocaleDateString()}</span>
                                </div>
                            </div>

                            <div className="space-y-3">
                                <div className="flex items-center gap-2 text-slate-600">
                                    <User className="w-4 h-4 text-slate-400" />
                                    <span className="font-medium">Haydovchi:</span>
                                    <span className="text-slate-800">{comment.driver.fio}</span>
                                    <span className="text-xs bg-slate-100 px-2 py-1 rounded-full text-slate-600">
                                        {comment.driver.number}
                                    </span>
                                </div>

                                <div className="flex items-center gap-2 text-slate-600">
                                    <FileText className="w-4 h-4 text-slate-400" />
                                    <span className="font-medium">Manba:</span>
                                    <span className="text-slate-800">{comment.source}</span>
                                </div>

                                {comment.comment ? (
                                    <div className="bg-slate-50 rounded-lg p-3 border-l-4 border-blue-400">
                                        <p className="text-slate-700 leading-relaxed">{comment.comment}</p>
                                    </div>
                                ) : (
                                    <div className="bg-slate-50 rounded-lg p-3 border-l-4 border-slate-300">
                                        <p className="text-slate-400 italic">Matnli izoh yo'q</p>
                                    </div>
                                )}

                                {comment.file_path ? (
                                    <div className="space-y-2">
                                        <div className="flex items-center gap-2 text-slate-600">
                                            <Image className="w-4 h-4 text-slate-400" />
                                            <span className="font-medium">Biriktirilgan rasm:</span>
                                        </div>
                                        <div className="relative group cursor-pointer" onClick={() => openImageModal(`https://mobile-test.izisol.uz/storage/comments/${comment.file_path}`)}>
                                            <img
                                                src={`https://mobile-test.izisol.uz/storage/comments/${comment.file_path}` || "/placeholder.svg"}
                                                alt={`Izoh ${comment.id} biriktirmasi`}
                                                className="w-full h-32 object-cover rounded-lg border border-slate-200 group-hover:border-blue-300 transition-all duration-300"
                                            />
                                            <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 rounded-lg transition-all duration-300 flex items-center justify-center">
                                                <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                                                    <div className="bg-white rounded-full p-2 shadow-lg">
                                                        <Image className="w-5 h-5 text-slate-600" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                ) : (
                                    <div className="flex items-center gap-2 text-slate-400">
                                        <Image className="w-4 h-4" />
                                        <span className="italic">Rasm biriktirilmagan</span>
                                    </div>
                                )}
                            </div>

                            {/* Replies Section */}
                            {comment.replies_count > 0 && (
                                <div className="mt-4 pt-3 border-t border-slate-100">
                                    <button
                                        onClick={() => toggleReplies(comment.id)}
                                        className="flex items-center gap-2 text-blue-600 hover:text-blue-700 transition-colors mb-3"
                                    >
                                        <Reply className="w-4 h-4" />
                                        <span className="font-medium">
                                            {expandedReplies.has(comment.id) ? 'Yashirish' : 'Korsatish'} Javoblar ({comment.replies_count})
                                        </span>
                                    </button>

                                    {expandedReplies.has(comment.id) && (
                                        <div className="space-y-3">
                                            {comment.replies.map((reply) => (
                                                <div key={reply.id} className="bg-blue-50 rounded-lg p-3 border-l-4 border-blue-400 ml-4">
                                                    <div className="flex justify-between items-start mb-2">
                                                        <div className="flex items-center gap-2">
                                                            <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center">
                                                                <span className="text-white text-xs font-semibold">A</span>
                                                            </div>
                                                            <span className="font-semibold text-blue-800">{reply.admin_name}</span>
                                                        </div>
                                                        <span className="text-xs text-slate-500">
                                                            {new Date(reply.created_at).toLocaleString()}
                                                        </span>
                                                    </div>

                                                    <p className="text-slate-700 mb-2">{reply.comment}</p>

                                                    {reply.files && reply.files.length > 0 && (
                                                        <div className="space-y-2">
                                                            <span className="text-xs text-blue-600 font-medium">
                                                                Biriktirmalar ({reply.files.length}):
                                                            </span>
                                                            <div className="grid grid-cols-2 gap-2">
                                                                {reply.files.map((filePath, fileIndex) => (
                                                                    <div
                                                                        key={fileIndex}
                                                                        className="relative group cursor-pointer"
                                                                        onClick={() => openImageModal(filePath)}
                                                                    >
                                                                        <img
                                                                            src={filePath || "/placeholder.svg"}
                                                                            alt={`Javob ${reply.id} biriktirmasi ${fileIndex + 1}`}
                                                                            className="w-full h-20 object-cover rounded border border-blue-200 group-hover:border-blue-400 transition-all duration-300"
                                                                        />
                                                                        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 rounded transition-all duration-300 flex items-center justify-center">
                                                                            <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                                                                                <div className="bg-white rounded-full p-1 shadow-lg">
                                                                                    <Image className="w-3 h-3 text-slate-600" />
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                ))}
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                </div>
                            )}

                            {/* Reply Section */}
                            <div className="mt-4 pt-3 border-t border-slate-100">
                                {replyingTo === comment.id ? (
                                    <div className="space-y-3">
                                        <textarea
                                            value={replyText}
                                            onChange={(e) => setReplyText(e.target.value)}
                                            placeholder="Javobingizni yozing..."
                                            className="w-full p-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                                            rows={3}
                                        />

                                        <div className="flex items-center gap-2">
                                            <input
                                                ref={fileInputRef}
                                                type="file"
                                                multiple
                                                onChange={handleFileSelect}
                                                className="hidden"
                                                id={`file-input-${comment.id}`}
                                            />
                                            <label
                                                htmlFor={`file-input-${comment.id}`}
                                                className="flex items-center gap-1 px-3 py-1.5 text-sm text-slate-600 hover:text-blue-600 cursor-pointer transition-colors"
                                            >
                                                <Paperclip className="w-4 h-4" />
                                                Fayl biriktirish
                                            </label>
                                            {replyFiles && replyFiles.length > 0 && (
                                                <span className="text-xs text-slate-500">
                                                    {replyFiles.length} fayl tanlandi
                                                </span>
                                            )}
                                        </div>

                                        <div className="flex gap-2">
                                            <button
                                                onClick={() => sendReply(comment.id)}
                                                disabled={sendingReply}
                                                className="flex items-center gap-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                                            >
                                                {sendingReply ? (
                                                    <Loader2 className="w-4 h-4 animate-spin" />
                                                ) : (
                                                    <Send className="w-4 h-4" />
                                                )}
                                                Javob yuborish
                                            </button>
                                            <button
                                                onClick={cancelReply}
                                                disabled={sendingReply}
                                                className="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                                            >
                                                Bekor qilish
                                            </button>
                                        </div>
                                    </div>
                                ) : (
                                    <div className="flex justify-between items-center">
                                        <p className="text-xs text-slate-500">{new Date(comment.created_at).toLocaleString()}</p>
                                        <button
                                            onClick={() => startReply(comment.id)}
                                            className="flex items-center gap-1 px-3 py-1.5 text-sm text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                                        >
                                            <Reply className="w-4 h-4" />
                                            Javob berish
                                        </button>
                                    </div>
                                )}
                            </div>
                        </div>
                    ))}
                </div>

                {/* Pagination */}
                {renderPaginationButtons()}

                {/* Image Modal */}
                {selectedImage && (
                    <div
                        className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4"
                        onClick={closeImageModal}
                    >
                        <div className="relative max-w-4xl max-h-full" onClick={(e) => e.stopPropagation()}>
                            <button
                                onClick={closeImageModal}
                                className="absolute -top-12 right-0 text-white hover:text-slate-300 transition-colors duration-200"
                            >
                                <X className="w-8 h-8" />
                            </button>
                            <img
                                src={selectedImage || "/placeholder.svg"}
                                alt="To'liq o'lchamdagi izoh biriktirmasi"
                                className="max-w-full max-h-[80vh] object-contain rounded-lg shadow-2xl"
                            />
                        </div>
                    </div>
                )}

                {/* Toast Container */}
                <ToastContainer
                    position="top-right"
                    autoClose={3000}
                    hideProgressBar={false}
                    newestOnTop
                    closeOnClick
                    rtl={false}
                    pauseOnFocusLoss
                    draggable
                    pauseOnHover
                    theme="colored"
                />
            </div>
        </div>
    );
};

export default Comments;