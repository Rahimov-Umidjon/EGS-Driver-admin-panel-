import {RotateCcw, SlidersHorizontal} from "lucide-react";
import {motion} from "framer-motion";
import QueueTable from "../../components/queueTable";
import api from "../../api/api.ts";
import {useEffect, useState} from "react";
import {BorderQueue} from "../queues";

// API dan qaytadigan pagination meta
interface PaginationMeta {
    current_page: number;
    last_page: number;
    per_page: number;
    total: number;
    from: number;
    to: number;
}

function Queuefailed() {

    const [currentPage, setCurrentPage] = useState<number>(1);
    const [loading, setLoading] = useState<boolean>(false);
    const [syncing, setSyncing] = useState<boolean>(false);
    const [data, setData] = useState<BorderQueue[]>([]);
    const [meta, setMeta] = useState<PaginationMeta | null>(null);

    const handleSync = () => {
        setSyncing(true);
        void getQueue(currentPage);
        setTimeout(() => setSyncing(false), 1800);
    };

    // Sahifa o'zgarganda qayta fetch qilish
    useEffect(() => {
        void getQueue(currentPage);
    }, [currentPage]);

    const getQueue = async (page: number) => {
        try {
            setLoading(true);
            // API ga page va per_page parametrlarini yuborish
            const res = await api.get(`/admin/queue/rejected-history`, {
                params: {
                    page,
                    // per_page: 10, // har sahifada nechta ko'rsatilsin
                }
            });

            const responseData = res.data.data.original.data;
            console.log(res);

            setData(responseData);
            setMeta({
                current_page:res?.data?.original?.current_page,
                last_page: res?.data?.original?.last_page,
                per_page: res?.data?.original?.per_page,
                total: res?.data?.original?.total,
                from: res?.data?.original?.from,
                to: res?.data?.original?.to,
            });


        } catch (error) {
            console.log(error);
        } finally {
            setLoading(false);
        }
    };




    return (
        <div className="min-h-screen bg-[#f0f4f3] p-8 font-sans">
            <div className="mx-auto">

                {/* Header */}
                <div className="flex items-start justify-between mb-7">
                    <div>
                        <h1 className="text-[22px] font-bold text-gray-900 leading-tight">
                            Verification Queue
                        </h1>
                        <p className="text-sm text-gray-500 mt-1">
                            Review and validate incoming driver documents and payment proofs.
                        </p>
                    </div>
                    <div className="flex items-center gap-2.5">
                        <button className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-gray-200 bg-white text-sm font-medium text-gray-600 hover:bg-gray-50 transition-colors">
                            <SlidersHorizontal size={14} />
                            Filters
                        </button>
                        <motion.button
                            onClick={handleSync}
                            whileTap={{ scale: 0.97 }}
                            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-semibold transition-colors"
                        >
                            <motion.span
                                animate={syncing ? { rotate: 360 } : { rotate: 0 }}
                                transition={syncing ? { repeat: Infinity, duration: 0.8, ease: "linear" } : {}}
                            >
                                <RotateCcw size={14} />
                            </motion.span>
                            Sync Queue
                        </motion.button>
                    </div>
                </div>



                {/* Table Card */}
                {meta && data && (
                    <QueueTable
                        loading={loading}
                        data={data}
                        meta={meta}
                        currentPage={currentPage}
                        setCurrentPage={setCurrentPage}
                    />
                )}
            </div>
        </div>
    );
}

export default Queuefailed;