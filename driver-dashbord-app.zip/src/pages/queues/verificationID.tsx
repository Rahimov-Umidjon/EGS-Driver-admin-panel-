import  {useEffect, useState} from "react";
import {motion, AnimatePresence} from "framer-motion";
import { useParams} from "react-router-dom";
import {
    XCircle,
    CreditCard,
    User,
    Phone,
    Truck,
    Hash,
    Calendar,
    DollarSign,
    ArrowRight, Database, CheckCircle2,
} from "lucide-react";
import api from "../../api/api.ts";
import FilesCard from "../../components/FilesCard/FilesCard.tsx";
import {toast} from "react-toastify";


interface File {
    id: number;
    queue_id: number;
    path: string;
    type: string;
    status: "approved" | "pending" | string;
    created_at: string; // yoki Date
    updated_at: string; // yoki Date
}

interface UploadFile {
    id: number;
    driver_id: number;
    admin_id: number | null;
    name: string;
    path: string;
    document_type: string;
    status: "approved" | "pending" | "rejected" | string;
    created_at: string; // yoki Date
    updated_at: string; // yoki Date
}

interface Driver {
    id: number;
    is_verified: "completed" | "pending" | string;
    in_egs: number;
    phone_number: string;
    telegram_chat_id: string;
    fio: string;
    number: string;
    source_db: string;
    is_existing_driver: boolean;
    additional_info: string;
    last_login_at: string; // yoki Date
    created_at: string; // yoki Date
    updated_at: string; // yoki Date
    deleted_at: string | null;
    is_online: number;
    fcm_token: string;
    upload_files?: UploadFile[];
}

export interface BorderQueue {
    id: number;
    driver_id: number;
    border_name: string;
    date: string; // yoki Date
    time_from: string;
    time_to: string;
    has_cmr: number;
    price: number;
    status: 'pending' | 'pending_review' | 'waiting_payment' | 'payment_uploaded' | 'approved' | 'rejected';
    created_at: string; // yoki Date
    updated_at: string; // yoki Date
    files?: File[];
    driver: Driver;
}









export default function PaymentVerification() {
    const [fullscreen, setFullscreen] = useState(false);
    const [selectImage, setSelectImage] = useState<string | null>(null);
    const [actionState, setActionState] = useState<'pending' | 'pending_review' | 'waiting_payment' | 'payment_uploaded' | 'approved' | 'rejected'>('rejected')
    const [data, setData] = useState<BorderQueue | null>(null);
    const [driver, setDriver] = useState<Driver | null>(null);
    const {id} = useParams();



    // Nechta element borligiga qarab grid columns o'zgaradi
    const getGridCols = (count: number) => {
        if (count === 1) return "grid-cols-1";
        if (count === 2) return "grid-cols-2";
        return "grid-cols-3"; // 3 va undan ko'p
    };

    const getQueueId = async () => {
        try {
            const res = await api.get(`/admin/queue/${id}`)
            console.log(res)
            setData(res.data);
            setActionState(res.data.status);
            setDriver(res.data.driver);

        } catch (error) {
            console.log(error);
        }
    }

    const handleApprove = async () => {
        try {
            const res = await api.post(`/admin/queue/${id}/approve`);
            console.log(res)
            toast.success("Ma'lumotlar tasdiqlandi")
        }catch (error:any) {
            console.log(error);
            toast.error(error?.response?.data?.message  );
        }
    }
    const handlePaymentApprove = async () => {
        try {
            const res = await api.post(`/admin/queue/${id}/approve-payment`);
            setActionState(res.data.status);
            toast.success("Navbat tasdiqlandi")
            console.log(res)
        }catch (error:any) {
            console.log(error);
            toast.error(error.response.data.message);

        }
    }




    useEffect(() => {
        if (id) {
            void getQueueId()
        }
    }, [id]);

    return (
        <div className="min-h-screen bg-[#f0f4f3] p-8 font-sans">
            <div className="mx-auto">

                {/* Breadcrumb */}
                <nav className="flex items-center justify-between gap-1.5 text-sm text-gray-400 mb-6">
                    <div className="flex flex-col sm:flex-row items-center justify-between   gap-4">
                        <h2 className="text-2xl  md:text-3xl font-bold text-indigo-700">
                            Navbatni tasdiqlash
                        </h2>
                    </div>

                    {
                        (actionState !== 'approved' && actionState !== "rejected")  && (
                            <div className={'flex gap-6 items-center'}>
                                <motion.button
                                    whileHover={{scale: 1.02}}
                                    whileTap={{scale: 0.97}}
                                    disabled={data?.files && (data?.files?.filter((obj)=> obj.status === 'rejected').length > 0 || data?.files?.filter((obj)=> obj.status === 'pending').length > 0)   }
                                    onClick={() => {
                                        handleApprove()
                                    }}
                                    className={`${ (data?.files  && (data?.files?.filter((obj)=> obj.status === 'rejected').length > 0 || data?.files?.filter((obj)=> obj.status === 'pending').length > 0)) ? 'cursor-no-drop' : ''} px-6 flex items-center justify-center gap-2 py-3.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-semibold text-[14px] transition-colors shadow-sm`}
                                >
                                    <CheckCircle2 size={16}/>
                                    Tasdiqlash
                                </motion.button>

                                <motion.button
                                    // disabled={(fileStatus === 'rejected')}
                                    whileHover={{scale: 1.02}}
                                    whileTap={{scale: 0.97}}
                                    onClick={() => setRejectModal({ open: true, type: "queue" })}

                                    className={` ${(data?.files  && data?.files?.filter((obj)=> obj.status === 'rejected').length > 0) ? 'cursor-no-drop' : ''} px-6 flex items-center justify-center gap-2 py-3.5 rounded-xl bg-white hover:bg-red-50 text-red-500 font-semibold text-[14px] border border-red-200 transition-colors shadow-sm`}
                                >
                                    <XCircle size={16}/>
                                    Bekor qilish
                                </motion.button>
                            </div>
                        )
                    }
                </nav>

                {/* Page Header */}
                {/*<div className="flex items-start justify-between mb-6">*/}
                {/*    <div>*/}
                {/*        <h1 className="text-[22px] font-bold text-gray-900 leading-tight">*/}
                {/*            Verify Payment Proof*/}
                {/*        </h1>*/}
                {/*        <p className="text-sm text-gray-400 mt-1">*/}
                {/*            Transaction ID:{" "}*/}
                {/*            <span className="font-medium text-gray-600">#TXN-88291044</span>*/}
                {/*        </p>*/}
                {/*    </div>*/}

                {/*</div>*/}

                <div className="grid grid-cols-[1fr_320px] gap-5">
                    {/* LEFT — Screenshot + Actions */}
                    <div className={`grid ${getGridCols(data?.files?.length || 1)} gap-4`}>
                        {
                            data?.files?.map((file: File) => (
                                <FilesCard setData={setData} actionState={actionState} setActionState={setActionState}
                                           setSelectImage={setSelectImage} setFullscreen={setFullscreen} file={file}
                                           key={file.id}/>
                            ))
                        }


                    </div>

                    {/* RIGHT — Driver Info + Transaction */}
                    <div className="flex flex-col gap-4">
                        {/* Driver Info Card */}
                        <motion.div
                            initial={{opacity: 0, y: 14}}
                            animate={{opacity: 1, y: 0}}
                            transition={{delay: 0.1, duration: 0.38}}
                            className="bg-white rounded-2xl shadow-sm overflow-hidden"
                        >
                            <div className="px-5 pt-4 pb-3 border-b border-gray-100">
                                <p className="text-[10.5px] font-bold text-gray-400 tracking-widest uppercase">
                                    Driver Information
                                </p>
                            </div>

                            {/* Avatar + Name */}
                            <div className="flex items-center gap-3 px-5 py-4 border-b border-gray-100">
                                <div
                                    className={`w-11 h-11 rounded-full flex items-center justify-center text-[14px] font-bold flex-shrink-0 bg-gray-200`}
                                >
                                    <p>
                                        {driver?.fio?.split(' ')[0]?.[0] || ''}
                                        {driver?.fio?.split(' ')[1]?.[0] || ''}
                                    </p>

                                </div>
                                <div>
                                    <p className="text-[14px] font-bold text-gray-900">
                                        {driver?.fio}
                                    </p>
                                    <p className="text-[11.5px] text-gray-400 mt-0.5">
                                        {driver?.phone_number}
                                    </p>
                                </div>
                            </div>

                            {/* Info Rows */}
                            <div className="px-5 py-3 space-y-3.5">
                                {[
                                    {icon: <Hash size={12}/>, label: "ID Number", value: driver?.id},
                                    {icon: <Phone size={12}/>, label: "Phone", value: driver?.phone_number},
                                    {icon: <Truck size={12}/>, label: "Number", value: driver?.number},
                                    {icon: <Database size={12}/>, label: "Source ", value: driver?.source_db},
                                ].map((row) => (
                                    <div key={row.label} className="flex items-center justify-between">
                                        <div className="flex items-center gap-1.5 text-[12px] text-gray-400">
                                            {row.icon}
                                            {row.label}
                                        </div>
                                        <span className="text-[12.5px] font-semibold text-gray-800">
                      {row.value}
                    </span>
                                    </div>
                                ))}
                            </div>

                            <div className="px-5 pb-4 pt-2">
                                <motion.button
                                    whileHover={{scale: 1.02}}
                                    whileTap={{scale: 0.97}}
                                    className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl border border-gray-200 text-[13px] font-semibold text-gray-700 hover:bg-gray-50 transition-colors"
                                >
                                    <User size={13}/>
                                    View Full Profile
                                </motion.button>
                            </div>
                        </motion.div>

                        {/* Transaction Details Card */}
                        <motion.div
                            initial={{opacity: 0, y: 14}}
                            animate={{opacity: 1, y: 0}}
                            transition={{delay: 0.18, duration: 0.38}}
                            className="bg-white rounded-2xl shadow-sm overflow-hidden"
                        >
                            <div className="px-5 pt-4 pb-3 border-b border-gray-100">
                                <p className="text-[10.5px] font-bold text-gray-400 tracking-widest uppercase">
                                    Transaction Details
                                </p>
                            </div>

                            <div className="px-5 py-4 space-y-4">
                                {/* Amount */}
                                <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-1.5 text-[12px] text-gray-400">
                                        <DollarSign size={12}/>
                                        Amount
                                    </div>
                                    <span className="text-[15px] font-bold text-gray-900">
                                         {
                                             data?.price + " UZS"
                                         }
                                    </span>
                                </div>

                                {/* Submitted On */}
                                <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-1.5 text-[12px] text-gray-400">
                                        <Calendar size={12}/>
                                        Submitted On
                                    </div>
                                    <span className="text-[12.5px] font-semibold text-gray-800">
                                        {data?.created_at ?  new Date(data?.created_at).toLocaleDateString("en-US")  : "-"}
                                    </span>
                                </div>

                                {/* Route */}
                                <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-1.5 text-[12px] text-gray-400">
                                        <ArrowRight size={12}/>
                                        Route
                                    </div>
                                    <span className="text-[12.5px] font-semibold text-gray-800">
                                        {data?.border_name}
                                    </span>
                                </div>

                                {/* Payment Type */}
                                <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-1.5 text-[12px] text-gray-400">
                                        <CreditCard size={12}/>
                                        Payment Type
                                    </div>
                                    <span
                                        className={`${actionState === 'approved' ? 'bg-emerald-50 text-emerald-700' : 'text-red-500 bg-red-200'} inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11.5px] font-semibold ring-1 ring-emerald-100`}>
                                        <CreditCard size={10}/>
                                        {actionState === 'approved' ? 'Payment Approved' : 'Payment Confirmed'}
                                    </span>
                                </div>
                            </div>

                            {
                                actionState === 'payment_uploaded' &&
                                (
                                    <div className={' px-4 pb-3'}>
                                        <motion.button
                                            whileHover={{scale: 1.02}}
                                            whileTap={{scale: 0.97}}
                                            onClick={() => {
                                                handlePaymentApprove()
                                            }}
                                            className={` flex w-full mb-2 items-center justify-center gap-2 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-semibold text-[14px] transition-colors shadow-sm`}
                                        >
                                            <CheckCircle2 size={16}/>
                                            Approve Payment
                                        </motion.button>
                                        <motion.button
                                            // disabled={(fileStatus === 'rejected')}
                                            whileHover={{scale: 1.02}}
                                            whileTap={{scale: 0.97}}
                                            onClick={() => setRejectModal({ open: true, type: "payment" })}

                                            className={`  flex w-full items-center justify-center gap-2 py-2 rounded-xl bg-white hover:bg-red-50 text-red-500 font-semibold text-[14px] border border-red-200 transition-colors shadow-sm`}
                                        >
                                            <XCircle size={16}/>
                                            Reject Payment
                                        </motion.button>
                                    </div>
                                )


                            }


                        </motion.div>


                    </div>
                </div>
            </div>

            {/* Fullscreen Image Modal */}
            <AnimatePresence>
                {fullscreen && (
                    <motion.div
                        initial={{opacity: 0}}
                        animate={{opacity: 1}}
                        exit={{opacity: 0}}
                        transition={{duration: 0.2}}
                        onClick={() => setFullscreen(false)}
                        className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-6 cursor-zoom-out"
                    >
                        <motion.img
                            initial={{scale: 0.92, opacity: 0}}
                            animate={{scale: 1, opacity: 1}}
                            exit={{scale: 0.92, opacity: 0}}
                            transition={{duration: 0.25}}
                            src={selectImage || ''}
                            alt="Payment proof fullscreen"
                            className="max-w-full max-h-full rounded-2xl shadow-2xl object-contain"
                            onClick={(e) => e.stopPropagation()}
                        />
                        <button
                            onClick={() => setFullscreen(false)}
                            className="absolute top-5 right-5 w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors"
                        >
                            <XCircle size={18}/>
                        </button>
                    </motion.div>
                )}
            </AnimatePresence>




        </div>
    );
}