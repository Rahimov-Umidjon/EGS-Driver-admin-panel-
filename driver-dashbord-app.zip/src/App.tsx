import {Suspense, lazy, useEffect} from "react";
import {Navigate, Route, BrowserRouter as Router, Routes} from "react-router-dom";
import {ToastContainer} from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';
import {useAuth} from "./context/AuthContext";
import Drivers from "./pages/driver";
import Files from "./pages/files";
import Passports from "./pages/passports";
import Chats from "./pages/chats";
import api from "./api/api.ts";

const Login = lazy(() => import("./pages/login"));
// const Order = lazy(() => import("./pages/order"));
const Layout = lazy(() => import("./layout"));
const NewMap = lazy(() => import("./pages/newMap"));
// const Chats = lazy(() => import("./pages/chats"));
const ChatsId = lazy(() => import("./pages/chatId"));
const VerificationQueue = lazy(() => import("./pages/queues"));
const VerificationQueueId = lazy(() => import("./pages/queues/verificationID.tsx"));
const Queuefailed = lazy(() => import("./pages/queue/queuefailed.tsx"));
const KazEPIFailed = lazy(() => import("./pages/kazepi/kazEPIFailed.tsx"));
const QueueSuccess = lazy(() => import("./pages/queue/queueSuccess.tsx"));
// const Drivers = lazy(() => import("./pages/drivers"));
// const Drivers = lazy(() => import("./pages/drivers"));
// const Carries = lazy(() => import("./pages/carriers"));
const Comments = lazy(() => import("./pages/comments"));
const ProtectedRoute = () => {
    const {isAuthenticated} = useAuth();
    return isAuthenticated ? <Layout/> : <Navigate to="/login" replace/>;
};
const AuthRedirect = () => {
    const {isAuthenticated} = useAuth();
    return !isAuthenticated ? <Login/> : <Navigate to="/new-map" replace/>;
};

const App = () => {
    const {loading} = useAuth();
    const {setUser} = useAuth();


    useEffect(() => {
        fetchUser();
    } , [])




    const fetchUser = async () => {
        try{
            const res = await api.get("/admin/profile");
            console.log(res);
            setUser(res.data);
        }catch(err){
            console.log(err);
        }
    }


    if (loading) return <div>Loading...</div>;


    return (
        <Router>
            <ToastContainer position="top-right" autoClose={2000}/>
            <Suspense fallback={<div>Loading...</div>}>
                <Routes>
                    <Route path="/login" element={<AuthRedirect/>}/>
                    <Route element={<ProtectedRoute/>}>
                        {/* <Route path="/order" element={<Order />} /> */}
                        {/*<Route path="/new-map" element={<NewMap />} />*/}
                        <Route path="/new-map" element={<NewMap/>}/>
                        <Route path="/chats/:id" element={
                            <Chats>
                                <ChatsId/>
                            </Chats>}/>
                        <Route path="/chats" element={
                            <Chats>
                                <ChatsId/>
                            </Chats>}/>
                        {/* <Route path="/carriers" element={<Carries />} /> */}
                        {/* <Route path="/drivers" element={<Drivers />} /> */}
                        <Route path="/comments" element={<Comments/>}/>
                        <Route path="/files" element={<Files/>}/>
                        <Route path="/drivers" element={<Drivers/>}/>
                        <Route path="/passports" element={<Passports/>}/>
                        <Route path="/document-verification" element={<VerificationQueue/>}/>
                        <Route path="/document-verification/:id" element={<VerificationQueueId/>}/>
                        <Route path="/queue-failed" element={<Queuefailed/>}/>
                        <Route path="/kazepi" element={<KazEPIFailed/>}/>
                        <Route path="/queue-success" element={<QueueSuccess/>}/>

                    </Route>
                    <Route path="*" element={<Navigate to="/new-map" replace/>}/>
                </Routes>
            </Suspense>
            <ToastContainer
                position="top-right"
                autoClose={3000}
                hideProgressBar={false}
                newestOnTop
                closeOnClick
                rtl={false}
                pauseOnFocusLoss
                draggable
                pauseOnHover
                theme="colored"
            />
        </Router>
    );
};

export default App;
